<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Migration_Version_178 extends CI_Migration
{
    function __construct()
    {
        parent::__construct();
    }

    public function up()
    {
        // Nothing to do here just update database number
    }
}
