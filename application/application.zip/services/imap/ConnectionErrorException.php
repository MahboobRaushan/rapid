<?php

namespace app\services\imap;

use Exception;

class ConnectionErrorException extends Exception
{
}
